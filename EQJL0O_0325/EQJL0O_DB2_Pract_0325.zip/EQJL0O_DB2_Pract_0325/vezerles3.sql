DECLARE
  v_min NUMBER := 10;
  v_max NUMBER := 100;
  ertek NUMBER := 78;
BEGIN
  IF ertek >= v_min AND ertek <= v_max THEN
    DBMS_OUTPUT.PUT_LINE('Az érték (' || ertek || ') beleesik az intervallumba.');
  ELSE
    DBMS_OUTPUT.PUT_LINE('Kívül esik.');
  END IF;
END;