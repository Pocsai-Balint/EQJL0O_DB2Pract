CREATE TABLE MasikPiros_Auto (
    rsz VARCHAR2(20),
    tipus VARCHAR2(20),
    szin VARCHAR2(20),
    kor NUMBER(3),
    ar NUMBER(10)
);

---------------------

SET SERVEROUTPUT ON;

DECLARE
    -- A kurzor neve: piros
    CURSOR piros IS
        SELECT rsz, tipus, szin, kor, ar
        FROM Piros_Auto
        WHERE szin = 'piros';
    
    -- A változó neve: x (átveszi a kurzor sorának típusát)
    x piros%ROWTYPE;

BEGIN
    -- 1. ADATOK ÁTMÁSOLÁSA KURZORRAL
    OPEN piros;
    LOOP
        FETCH piros INTO x;
        EXIT WHEN piros%NOTFOUND;
        
        INSERT INTO MasikPiros_Auto (rsz, tipus, szin, kor, ar)
        VALUES (x.rsz, x.tipus, x.szin, x.kor, x.ar);
    END LOOP;
    CLOSE piros;
    
    COMMIT;

    -- 2. A MASIKPIROS_AUTO TÁBLA TARTALMÁNAK KILISTÁZÁSA
    DBMS_OUTPUT.PUT_LINE('--- A MasikPiros_Auto tábla tartalma ---');
    
    -- Egy egyszerű ciklussal kilistázzuk a frissített táblát
    FOR lista IN (SELECT * FROM MasikPiros_Auto) LOOP
        DBMS_OUTPUT.PUT_LINE('Rendszám: ' || lista.rsz || 
                             ' | Típus: ' || lista.tipus || 
                             ' | Szín: ' || lista.szin || 
                             ' | Kor: ' || lista.kor || 
                             ' | Ár: ' || lista.ar);
    END LOOP;

EXCEPTION
    WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE('Hiba történt: ' || SQLERRM);
        IF piros%ISOPEN THEN
            CLOSE piros;
        END IF;
END;

----------------------

PirosAutoFor-ba veló eltárolás

BEGIN
    -- Kurzor FOR ciklus használata
    -- A ciklus változója (x) automatikusan deklarálódik a lekérdezés alapján
    FOR x IN (SELECT rsz, tipus, szin, kor, ar 
              FROM Piros_Auto 
              WHERE szin = 'piros') 
    LOOP
        -- Adatok beszúrása a másik táblába
        INSERT INTO MasikPiros_Auto (rsz, tipus, szin, kor, ar)
        VALUES (x.rsz, x.tipus, x.szin, x.kor, x.ar);
        
        -- Opcionális: Visszajelzés a konzolra
        DBMS_OUTPUT.PUT_LINE('Átmásolva: ' || x.rsz || ' (' || x.tipus || ')');
    END LOOP;

    -- Tranzakció véglegesítése
    COMMIT;
    
    DBMS_OUTPUT.PUT_LINE('A piros autók átmásolása FOR ciklussal befejeződött.');
END;
