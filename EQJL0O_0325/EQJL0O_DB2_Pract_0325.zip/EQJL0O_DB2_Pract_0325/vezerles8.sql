DECLARE
  n NUMBER := 10;
  a NUMBER := 0;
  b NUMBER := 1;
  temp NUMBER;
BEGIN
  DBMS_OUTPUT.PUT_LINE('Az első ' || n || ' Fibonacci szám:');
  FOR i IN 1..n LOOP
    DBMS_OUTPUT.PUT_LINE(a);
    temp := a + b;
    a := b;
    b := temp;
  END LOOP;
END;