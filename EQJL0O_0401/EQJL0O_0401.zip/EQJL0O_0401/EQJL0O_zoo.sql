Create Table zoo(
ID int primary key, 
Nev varchar2 (30),
Fajta varchar2 (30),
Szuletett date,
Suly  int,
Ertek int,
Gondozo varhar2 (30)
);

disc zoo;

-------------------------------

INSERT INTO Zoo Values(13, 'Bruce', 'Majom',TO_DATE('11.10.2011', 'DD-MM-YYYY'9, 40,1000000,'Boldog Éva');

-------------------------------

CREATE OR REPLACE PROCEDURE ErtekNovel(szazalek IN INT) is
BEGIN
update Zoo SET Ertek=Ertek +(Ertek*szazalek/100);
END;
SELECT*FROM Zoo;
BEGIN
ErtekNovel(10);
END;
SELECT*FROM Zoo;
-------------------------------




