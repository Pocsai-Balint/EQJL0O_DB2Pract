DECLARE
  a NUMBER := 3;
  b NUMBER := 4;
  c NUMBER := 5;
  s NUMBER;
  T NUMBER;
BEGIN
  -- Félkerület kiszámítása
  s := (a + b + c) / 2;
  -- Terület kiszámítása a Héron-képlettel (SQRT = négyzetgyök)
  T := SQRT(s * (s - a) * (s - b) * (s - c));
  
  DBMS_OUTPUT.PUT_LINE('A háromszög területe: ' || T);
END;