DECLARE
  r NUMBER := 12;
  terulet NUMBER;
  pi CONSTANT NUMBER := 3.14159;
BEGIN
  terulet := r * r * pi;
  DBMS_OUTPUT.PUT_LINE('A kör területe: ' || terulet);
END;