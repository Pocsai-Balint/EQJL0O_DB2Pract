CREATE OR REPLACE PROCEDURE aut_arnov1 AS
    -- A kurzor neve: cur_a
    -- Kiválasztjuk a piros autók rendszámát és árát
    CURSOR cur_a IS
        SELECT rsz, ar
        FROM Piros_Auto
        WHERE szin = 'piros'
        FOR UPDATE; -- Jelzi az adatbázisnak, hogy módosítani fogjuk ezeket a sorokat

    v_rsz Piros_Auto.rsz%TYPE;
    v_ar  Piros_Auto.ar%TYPE;
BEGIN
    OPEN cur_a;
    LOOP
        FETCH cur_a INTO v_rsz, v_ar;
        EXIT WHEN cur_a%NOTFOUND;

        -- Árnövelés 10%-kal (ar * 1.1)
        UPDATE Piros_Auto
        SET ar = ar * 1.1
        WHERE rsz = v_rsz;
        
        DBMS_OUTPUT.PUT_LINE('Rendszám: ' || v_rsz || ' - Új ár: ' || (v_ar * 1.1));
    END LOOP;
    CLOSE cur_a;
    
    COMMIT;
    DBMS_OUTPUT.PUT_LINE('Az áremelés sikeresen megtörtént.');
END;
