DECLARE
  s number;
BEGIN
  s := (a + b);
  DBMS_OUTPUT.PUT_LINE(TO_CHAR(s));
END;