CREATE TABLE Zoo (
    ID NUMBER(38, 0) NOT NULL,
    NEV VARCHAR2(30 BYTE),
    FAJTA VARCHAR2(30 BYTE),
    SZULETETT DATE,
    SULY NUMBER(38, 0),
    ERTEK NUMBER(38, 0),
    GONDOZO VARCHAR2(30 BYTE),
    PRIMARY KEY (ID)
);

------------------------


BEGIN
    INSERT INTO Zoo VALUES (1, 'Nelly', 'Elefánt', ('2010-03-26', 'YYYY-MM-DD'), 3500, 3030303, 'Kis János');
    INSERT INTO Zoo VALUES (2, 'Molly', 'Majom', ('2010-03-24', 'YYYY-MM-DD'), 40, 227273, 'Kis János');
    INSERT INTO Zoo VALUES (3, 'Decker', 'Elefánt', ('2010-03-24', 'YYYY-MM-DD'), 2200, 2272727, 'Kis János');
    INSERT INTO Zoo VALUES (4, 'Dotty', 'Zsiráf', ('2005-09-25', 'YYYY-MM-DD'), 890, 2272727, 'Kis János');
    INSERT INTO Zoo VALUES (5, 'Betsy', 'Teve', ('2003-08-24', 'YYYY-MM-DD'), 1750, 3030303, 'Kis János');
    INSERT INTO Zoo VALUES (6, 'Lee', 'Tigris', ('2001-11-17', 'YYYY-MM-DD'), 350, 800000, 'Kemény Péter');
    INSERT INTO Zoo VALUES (7, 'Hank', 'Zsiráf',('2005-12-11', 'YYYY-MM-DD'), 930, 2400000, 'Kis János');
    INSERT INTO Zoo VALUES (8, 'Foxi', 'Róka', ('2012-05-20', 'YYYY-MM-DD'), 55, 250000, 'Kemény Péter');
    INSERT INTO Zoo VALUES (9, 'Neo', 'Pingvin', ('2005-10-18', 'YYYY-MM-DD'), 40, 100000, 'Boldog Éva');
    INSERT INTO Zoo VALUES (10, 'Bruce', 'Cápa', ('2007-04-06', 'YYYY-MM-DD'), 280, 1000000, 'Boldog Éva');

    COMMIT;
END;


-----------------

1.feladat NewPet

CREATE OR REPLACE PROCEDURE NewPet(id IN NUMBER, n IN VARCHAR2, f IN VARCHAR2, s1 IN NUMBER, s2 IN NUMBER, g IN VARCHAR2) AS
BEGIN
    INSERT INTO Zoo (ID, NEV, FAJTA, SZULETETT, SULY, ERTEK, GONDOZO)
    VALUES (id, n, f, SYSDATE, s1, s2, g);
    COMMIT;
    DBMS_OUTPUT.PUT_LINE('Új állat rögzítve: ' || n);
END;


----------------------

2.feladat DelPet

CREATE OR REPLACE PROCEDURE DelPet(p_id IN NUMBER) AS
BEGIN
    DELETE FROM Zoo WHERE ID = p_id;
    
    IF SQL%ROWCOUNT > 0 THEN
        DBMS_OUTPUT.PUT_LINE('A rekord törölve lett! (ID: ' || p_id || ')');
    ELSE
        DBMS_OUTPUT.PUT_LINE('Hiba: Nem létezik állat ezzel az ID-vel: ' || p_id);
    END IF;
    COMMIT;
END;

---------------------------

3. feldat ModPet

CREATE OR REPLACE PROCEDURE ModPet(td IN NUMBER, fn IN VARCHAR2, d IN VARCHAR2) AS
    v_sql VARCHAR2(200);
BEGIN
    -- td: ID, fn: oszlop neve, d: új érték
    v_sql := 'UPDATE Zoo SET ' || fn || ' = :1 WHERE ID = :2';
    
    EXECUTE IMMEDIATE v_sql USING d, td;
    
    IF SQL%ROWCOUNT > 0 THEN
        DBMS_OUTPUT.PUT_LINE('Adat sikeresen módosítva.');
    ELSE
        DBMS_OUTPUT.PUT_LINE('Nem található rekord ezzel az ID-vel.');
    END IF;
    COMMIT;
END;

----------------------------

4. feladat PetData


CREATE OR REPLACE PROCEDURE PetData(p_id IN NUMBER) AS
    v_nev Zoo.NEV%TYPE;
    v_fajta Zoo.FAJTA%TYPE;
    v_gondozo Zoo.GONDOZO%TYPE;
BEGIN
    SELECT NEV, FAJTA, GONDOZO INTO v_nev, v_fajta, v_gondozo
    FROM Zoo
    WHERE ID = p_id;

    DBMS_OUTPUT.PUT_LINE('Név: ' || v_nev || ', Fajta: ' || v_fajta || ', Gondozó: ' || v_gondozo);

EXCEPTION
    WHEN NO_DATA_FOUND THEN
        DBMS_OUTPUT.PUT_LINE('Hiba: Nem létezik állat ezzel az ID-vel: ' || p_id);
END;

--------------------------------

5. feladat PetData2

CREATE OR REPLACE PROCEDURE PetData2(p_name IN VARCHAR2) AS
    v_fajta Zoo.FAJTA%TYPE;
    v_ertek Zoo.ERTEK%TYPE;
BEGIN
    SELECT FAJTA, ERTEK INTO v_fajta, v_ertek
    FROM Zoo
    WHERE NEV = p_name;

    DBMS_OUTPUT.PUT_LINE('Fajta: ' || v_fajta || ', Érték: ' || v_ertek);

EXCEPTION
    WHEN NO_DATA_FOUND THEN
        DBMS_OUTPUT.PUT_LINE('Hiba: Nem létezik ' || p_name || ' nevű állat.');
    WHEN TOO_MANY_ROWS THEN
        DBMS_OUTPUT.PUT_LINE('Hiba: Több állat is létezik ezzel a névvel!');
END;

-------------------------------

6.feladat ThereIsPetCalled

CREATE OR REPLACE FUNCTION ThereIsPetCalled(p_name IN VARCHAR2) 
RETURN VARCHAR2 AS
    v_count NUMBER;
BEGIN
    -- Megszámoljuk, hány ilyen nevű állat van
    SELECT COUNT(*) INTO v_count
    FROM Zoo
    WHERE NEV = p_name;

    -- Ha a szám nagyobb mint 0, akkor van ilyen állat
    IF v_count > 0 THEN
        RETURN 'yes';
    ELSE
        RETURN 'no';
    END IF;
END;

