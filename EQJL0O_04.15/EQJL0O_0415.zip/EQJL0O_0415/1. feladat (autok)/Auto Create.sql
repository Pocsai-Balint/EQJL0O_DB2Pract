CREATE TABLE Piros_Auto (
    rsz VARCHAR2(6),
    tipus VARCHAR2(30),
    szin VARCHAR2(20),
    kor NUMBER(3),
    ar NUMBER(10)
);

------------------

BEGIN
    INSERT INTO Piros_Auto (rsz, tipus, szin, kor, ar) VALUES ('ABC500', 'Opel Corsa', 'piros', 8, 800000);
    INSERT INTO Piros_Auto (rsz, tipus, szin, kor, ar) VALUES ('MCC325', 'Opel Insignia', 'fekete', 2, 6800000);
    INSERT INTO Piros_Auto (rsz, tipus, szin, kor, ar) VALUES ('BBM104', 'Suzuki Swift', 'piros', 5, 1500000);
    INSERT INTO Piros_Auto (rsz, tipus, szin, kor, ar) VALUES ('CHR411', 'Renault Twingo', 'piros', 12, 700000);
    INSERT INTO Piros_Auto (rsz, tipus, szin, kor, ar) VALUES ('JRZ932', 'BMW M3', 'fekete', 5, 4500000);
    INSERT INTO Piros_Auto (rsz, tipus, szin, kor, ar) VALUES ('JEG113', 'Opel Corsa', 'piros', 7, 900000);
    INSERT INTO Piros_Auto (rsz, tipus, szin, kor, ar) VALUES ('DER842', 'Seat Ibiza', 'szürke', 14, 500000);
    INSERT INTO Piros_Auto (rsz, tipus, szin, kor, ar) VALUES ('BAB422', 'Lada 1300S', 'fehér', 28, 220000);
    INSERT INTO Piros_Auto (rsz, tipus, szin, kor, ar) VALUES ('UFF666', 'Audi TT', 'fekete', 4, 7500000);

    
    COMMIT;
END;

---------------------