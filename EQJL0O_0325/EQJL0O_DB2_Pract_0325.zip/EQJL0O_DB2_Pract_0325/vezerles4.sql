DECLARE
  beosztas VARCHAR2(20) := 'root';
BEGIN
  CASE beosztas
    WHEN 'root' THEN DBMS_OUTPUT.PUT_LINE('Rendszergazda (UNIX/LINUX)');
    WHEN 'admin' THEN DBMS_OUTPUT.PUT_LINE('Adminisztrátor');
    ELSE DBMS_OUTPUT.PUT_LINE('Ismeretlen beosztás');
  END CASE;
END;