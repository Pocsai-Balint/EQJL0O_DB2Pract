CREATE TABLE Circles (
    RADIUS NUMBER(4) PRIMARY KEY,
    CIRCUMFERENCE NUMBER,
    AREA NUMBER
);


-------------------------------

DESC Circles 
SELECT 1 Radius, 2*1*30.141592654 Circumferene from dual;

CREATE or REPLACE Function PI return number AS
BEGIN 
RETURN 3.141592654;
END;

-------------------------------

select 1 radius, 2*1-PI() Circumference from dual;

-------------------------------

declare 
radius number:=1;
circumference number;
begin Circumference:= 2*Radius*PI();
DBMS_OUTPUT.UT_LINE('Radous? '||Radius||'Circumference: '
||Circumference);
END;

-------------------------------

DECLARE
Cirmference number;
x number:=1;
y number:=5;

BEGIN
FOR i IN x..y LOOP
Circumference:=2*i*PI();
dbms_output.put_Line('Radius: '||i||'Circumference: '
||Circumference);
END LOOP;
END;

-------------------------------

create or replace Produce Circler (x in number, y in number)is 
Circumference number;
BEGIN 
FOR i IN x..y LOOP
Circumference:=2*i*PI();
dbms_output.put_Line('Radius: '||i||'Circumference: '
||Circumference);
END LOOP;
END;
-------------------------------
BEGIN
Circler (1,5);
END
-------------------------------
create or replace Produce Circler (x in number, y in number) IS
Circumference number;
Area number;
BEGIN 
FOR i IN x..y LOOP
Circumference:=2*i*PI();
Area:= POWER (i, 2)*PI();
dbms_output.put_Line('Radius: '||i||'Circumference: '
||Circumference)||'Area: '||Area);
END LOOP;
END;
-------------------------------
create or replace Produce Circler (x in number, y in number) IS 
Circumference number;
Area number;
BEGIN 
FOR i IN x..y LOOP
Circumference:=2*i*PI();
Area:= POWER (i, 2)*PI();
INSERT INTO Circles VALES (i, Circumference, Area);
END LOOP;
dbms_output.put_Line('A Circles tábla bekerültek az adatok.');
END;
-------------------------------
BEGIN
Circler (1,5);
END
-------------------------------





































