DECLARE
  vnev VARCHAR2(50) := 'Vezetéknév ';
  knev VARCHAR2(50) := 'Keresztnév';
BEGIN
  DBMS_OUTPUT.PUT_LINE(vnev || knev);
END;