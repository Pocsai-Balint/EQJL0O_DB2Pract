CREATE OR REPLACE PROCEDURE aut_arnov4 AS
    -- A kurzor neve: cur_a
    CURSOR cur_a IS
        SELECT rsz
        FROM Piros_Auto
        WHERE szin = 'piros'
        FOR UPDATE;

    -- Változók deklarálása
    v_rsz Piros_Auto.rsz%TYPE;
    db    NUMBER := 0; -- Számláló változó, 0-ról indítva
BEGIN
    OPEN cur_a;
    LOOP
        FETCH cur_a INTO v_rsz;
        EXIT WHEN cur_a%NOTFOUND;

        -- Árnövelés 10%-kal
        UPDATE Piros_Auto
        SET ar = ar * 1.1
        WHERE rsz = v_rsz;

        -- A számláló növelése minden sikeres update után
        db := db + 1;
    END LOOP;
    CLOSE cur_a;

    COMMIT;

    -- Az eredmény kiírása
    DBMS_OUTPUT.PUT_LINE('Az áremelés befejeződött.');
    DBMS_OUTPUT.PUT_LINE('Módosított autók száma: ' || db);
END;