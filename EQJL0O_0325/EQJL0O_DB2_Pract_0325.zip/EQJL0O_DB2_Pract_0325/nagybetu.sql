DECLARE
  vnev VARCHAR2(50) := 'Kovács';
  knev VARCHAR2(50) := 'János';
BEGIN
  DBMS_OUTPUT.PUT_LINE(UPPER(vnev || ' ' || knev));
  DBMS_OUTPUT.PUT_LINE(LOWER(vnev || ' ' || knev));
END;