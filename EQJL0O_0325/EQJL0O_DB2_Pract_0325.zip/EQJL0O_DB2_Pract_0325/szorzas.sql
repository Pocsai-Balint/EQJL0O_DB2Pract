DECLARE
  a NUMBER := 6;
  b NUMBER := 8;
  eredmeny NUMBER;
BEGIN
  eredmeny := a * b;
  DBMS_OUTPUT.PUT_LINE('A szorzat: ' || eredmeny);
END;