DECLARE
  n NUMBER := 10;
  v_oszto_db NUMBER := 0;
BEGIN
  FOR i IN 1..n LOOP
    IF MOD(n, i) = 0 THEN
      v_oszto_db := v_oszto_db + 1;
    END IF;
  END LOOP;

  IF v_oszto_db = 2 THEN
    DBMS_OUTPUT.PUT_LINE(n || ' egy prímszám.');
  ELSE
    DBMS_OUTPUT.PUT_LINE(n || ' nem prímszám.');
  END IF;
END;